<?php $__env->startSection('title', 'Transactions - Banking System'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Transaction History</h2>

    <?php if($transactions->isEmpty()): ?>
        <p class="muted">No transactions recorded yet.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Date</th>
                <th>Account</th>
                <th>Type</th>
                <th class="num">Amount</th>
                <th>Reference</th>
                <th>Notes</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($transaction->created_at->format('d M Y H:i')); ?></td>
                    <td><?php echo e($transaction->account->account_number); ?></td>
                    <td>
                        <span class="badge badge-<?php echo e($transaction->type); ?>">
                            <?php echo e(ucfirst($transaction->type)); ?>

                        </span>
                    </td>
                    <td class="num">$ <?php echo e(number_format((float) $transaction->amount, 2)); ?></td>
                    <td><code><?php echo e($transaction->reference_number); ?></code></td>
                    <td class="muted"><?php echo e($transaction->notes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="margin-top:16px">
            <?php echo e($transactions->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Exam.1\resources\views/transactions/index.blade.php ENDPATH**/ ?>