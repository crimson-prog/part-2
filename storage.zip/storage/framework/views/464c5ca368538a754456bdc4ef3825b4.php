<?php $__env->startSection('title', 'New Transaction - Banking System'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:620px">
    <h1>New Transaction</h1>
    <p class="sub">Deposits add money to the balance. Withdrawals are rejected if the balance would fall below the minimum balance.</p>

    <form method="POST" action="<?php echo e(route('transactions.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="field">
            <label for="account_id">Account</label>
            <select id="account_id" name="account_id" required>
                <option value="">-- Select an account --</option>
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($account->id); ?>" <?php if(old('account_id') == $account->id): echo 'selected'; endif; ?>>
                        <?php echo e($account->account_number); ?> - balance $ <?php echo e(number_format((float) $account->balance, 2)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="row">
            <div class="field">
                <label for="type">Type</label>
                <select id="type" name="type" required>
                    <option value="deposit" <?php if(old('type') === 'deposit'): echo 'selected'; endif; ?>>Deposit</option>
                    <option value="withdrawal" <?php if(old('type') === 'withdrawal'): echo 'selected'; endif; ?>>Withdrawal</option>
                </select>
            </div>

            <div class="field">
                <label for="amount">Amount</label>
                <input id="amount" type="number" step="0.01" min="1" name="amount" value="<?php echo e(old('amount')); ?>" required>
            </div>
        </div>

        <div class="field">
            <label for="reference_number">Reference number (optional)</label>
            <input id="reference_number" type="text" name="reference_number" value="<?php echo e(old('reference_number')); ?>"
                   placeholder="Generated automatically when left empty">
        </div>

        <div class="field">
            <label for="notes">Notes (optional)</label>
            <textarea id="notes" name="notes" rows="3"><?php echo e(old('notes')); ?></textarea>
        </div>

        <button type="submit" class="btn">Save transaction</button>
        <a href="<?php echo e(route('transactions.index')); ?>" class="btn" style="background:#64748b">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Exam.1\resources\views/transactions/create.blade.php ENDPATH**/ ?>