@extends('layouts.app')

@section('title', 'Dashboard - Banking System')

@section('content')
<h1>Dashboard</h1>
<p class="sub">Live statistics refresh automatically every 30 seconds (AJAX polling).</p>

<div class="grid">
    <div class="stat">
        <div class="label">Total Accounts</div>
        <div class="value" id="total-accounts">-</div>
    </div>
    <div class="stat">
        <div class="label">Total Money in Bank</div>
        <div class="value" id="total-money">-</div>
    </div>
    <div class="stat">
        <div class="label">Transactions Today</div>
        <div class="value" id="total-transactions">-</div>
    </div>
    <div class="stat">
        <div class="label">Last Updated</div>
        <div class="value" id="last-updated" style="font-size:18px">-</div>
    </div>
</div>

<div class="card">
    <h2>My Accounts</h2>
    @if ($accounts->isEmpty())
        <p class="muted">No accounts yet. Run <code>php artisan db:seed</code> to load the demo data.</p>
    @else
        <table>
            <thead>
            <tr>
                <th>Account Number</th>
                <th class="num">Balance</th>
                <th class="num">Minimum Balance</th>
                <th class="num">Transactions</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            @foreach ($accounts as $account)
                <tr>
                    <td>{{ $account->account_number }}</td>
                    <td class="num">$ {{ number_format((float) $account->balance, 2) }}</td>
                    <td class="num">$ {{ number_format((float) $account->minimum_balance, 2) }}</td>
                    <td class="num">{{ $account->transactions_count }}</td>
                    <td>
                        @if ($account->isLowBalance())
                            <span class="badge badge-low">Low balance</span>
                        @else
                            <span class="badge badge-deposit">Healthy</span>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    @endif
</div>

<div class="card">
    <h2>Notifications</h2>
    @if ($notifications->isEmpty())
        <p class="muted">No notifications yet.</p>
    @else
        <ul class="list-none">
            @foreach ($notifications as $notification)
                <li>
                    {{ $notification->data['message'] ?? 'Notification' }}
                    <span class="muted">- {{ $notification->created_at->diffForHumans() }}</span>
                </li>
            @endforeach
        </ul>
    @endif
</div>
@endsection

@push('scripts')
<script>
    const STATS_URL = '/api/dashboard/stats';

    async function refreshStats() {
        try {
            const response = await fetch(STATS_URL, { headers: { 'Accept': 'application/json' } });

            if (!response.ok) {
                return;
            }

            const stats = await response.json();

            document.getElementById('total-accounts').textContent = stats.total_accounts;
            document.getElementById('total-money').textContent = '$ ' + stats.total_money;
            document.getElementById('total-transactions').textContent = stats.total_transactions_today;
            document.getElementById('last-updated').textContent = stats.generated_at;
        } catch (error) {
            console.error('Unable to load dashboard stats', error);
        }
    }

    refreshStats();
    setInterval(refreshStats, 30000);
</script>
@endpush
