<?php $__env->startSection('title', 'Login - Banking System'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:420px;margin:60px auto">
    <h1>Sign in</h1>
    <p class="sub">Use the demo account: <code>demo@bank.test</code> / <code>password</code></p>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <div class="field">
            <label for="email">Email</label>
            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        </div>

        <div class="field">
            <label for="password">Password</label>
            <input id="password" type="password" name="password" required>
        </div>

        <button type="submit" class="btn">Login</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Exam.1\resources\views/auth/login.blade.php ENDPATH**/ ?>