<?php $__env->startSection('title', 'Dashboard - Banking System'); ?>

<?php $__env->startSection('content'); ?>
<h1>Dashboard</h1>
<p class="sub">Live statistics refresh automatically every 30 seconds (AJAX polling).</p>

<div class="grid">
    <div class="stat">
        <div class="label">Total Accounts</div>
        <div class="value" id="total-accounts">-</div>
    </div>
    <div class="stat">
        <div class="label">Total Money in Bank</div>
        <div class="value" id="total-money">-</div>
    </div>
    <div class="stat">
        <div class="label">Transactions Today</div>
        <div class="value" id="total-transactions">-</div>
    </div>
    <div class="stat">
        <div class="label">Last Updated</div>
        <div class="value" id="last-updated" style="font-size:18px">-</div>
    </div>
</div>

<div class="card">
    <h2>My Accounts</h2>
    <?php if($accounts->isEmpty()): ?>
        <p class="muted">No accounts yet. Run <code>php artisan db:seed</code> to load the demo data.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Account Number</th>
                <th class="num">Balance</th>
                <th class="num">Minimum Balance</th>
                <th class="num">Transactions</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($account->account_number); ?></td>
                    <td class="num">$ <?php echo e(number_format((float) $account->balance, 2)); ?></td>
                    <td class="num">$ <?php echo e(number_format((float) $account->minimum_balance, 2)); ?></td>
                    <td class="num"><?php echo e($account->transactions_count); ?></td>
                    <td>
                        <?php if($account->isLowBalance()): ?>
                            <span class="badge badge-low">Low balance</span>
                        <?php else: ?>
                            <span class="badge badge-deposit">Healthy</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Notifications</h2>
    <?php if($notifications->isEmpty()): ?>
        <p class="muted">No notifications yet.</p>
    <?php else: ?>
        <ul class="list-none">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($notification->data['message'] ?? 'Notification'); ?>

                    <span class="muted">- <?php echo e($notification->created_at->diffForHumans()); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const STATS_URL = '/api/dashboard/stats';

    async function refreshStats() {
        try {
            const response = await fetch(STATS_URL, { headers: { 'Accept': 'application/json' } });

            if (!response.ok) {
                return;
            }

            const stats = await response.json();

            document.getElementById('total-accounts').textContent = stats.total_accounts;
            document.getElementById('total-money').textContent = '$ ' + stats.total_money;
            document.getElementById('total-transactions').textContent = stats.total_transactions_today;
            document.getElementById('last-updated').textContent = stats.generated_at;
        } catch (error) {
            console.error('Unable to load dashboard stats', error);
        }
    }

    refreshStats();
    setInterval(refreshStats, 30000);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Exam.1\resources\views/dashboard.blade.php ENDPATH**/ ?>